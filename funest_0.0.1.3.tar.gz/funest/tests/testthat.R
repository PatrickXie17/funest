library(testthat)
library(funest)

test_check("funest")
