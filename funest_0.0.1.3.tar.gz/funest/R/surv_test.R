#' A sample of short form of testing data
#'
#' This contains the short form of the simulated testing data.
#'
#' @docType data
#'
#' @usage data(surv_test)
#'
#' @format data.frame
#'
#' @keywords datasets
#'
#' @examples
#' data(surv_test)
"surv_test"
