#' A sample of long form of training data
#'
#' This contains the long form of the simulated training data.
#'
#' @docType data
#'
#' @usage data(long_train)
#'
#' @format data.frame
#'
#' @keywords datasets
#'
#' @examples
#' data(long_train)
"long_train"
