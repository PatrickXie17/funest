#' A sample of long form of testing data
#'
#' This contains the long form of the simulated testing data.
#'
#' @docType data
#'
#' @usage data(long_test)
#'
#' @format data.frame
#'
#' @keywords datasets
#'
#' @examples
#' data(long_test)
"long_test"
