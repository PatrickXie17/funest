#' A sample of short form of training data
#'
#' This contains the short form of the simulated training data.
#'
#' @docType data
#'
#' @usage data(surv_train)
#'
#' @format data.frame
#'
#' @keywords datasets
#'
#' @examples
#' data(surv_train)
"surv_train"
